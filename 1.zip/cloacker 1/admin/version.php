<h2>
    <a href="https://yellowweb.top/donate" target="_blank">
        Version: 01.09.2023
        <br />
        PHP: <?= phpversion() ?>
        <br /> Please, donate!
    </a>
</h2>
